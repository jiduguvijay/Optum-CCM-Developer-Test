package com.optum.test.userdata.repos;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.optum.test.userdata.entities.UserData;

public interface UserDataRepo extends PagingAndSortingRepository<UserData, Long> {

}
