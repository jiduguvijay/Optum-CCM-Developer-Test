package com.optum.test.userdata.controllers;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.optum.test.userdata.entities.UserData;
import com.optum.test.userdata.repos.UserDataRepo;

@RestController
@RequestMapping("/UserData")
public class UserDataController 
{
	@Autowired
	UserDataRepo userDataRepo;
	
	@GetMapping
	public List<UserData> getAll()
	{
		return (List<UserData>) userDataRepo.findAll();
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<UserData> getById(@PathVariable long id)
	{
		Optional<UserData> userInfo = userDataRepo.findById(id);
		if(userInfo.isPresent())
		{
			return new ResponseEntity<UserData>(userInfo.get(), HttpStatus.OK) ;
		}
		else
		{
			return new ResponseEntity<UserData>(HttpStatus.NOT_FOUND) ;
		}
	}
	
	@PostMapping
	public ResponseEntity<Void> createNewUserData(@RequestBody UserData userData)
	{
		userData.setId(0);
		userData.getAddress().setId(0);
		userDataRepo.save(userData);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
	
	@PutMapping
	public ResponseEntity<Void> updateUserData(@RequestBody UserData userData)
	{
		userDataRepo.save(userData);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteUserData(@PathVariable long id)
	{
		userDataRepo.deleteById(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
