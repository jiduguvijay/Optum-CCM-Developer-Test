package com.optum.test.userdata.controllers;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.test.userdata.entities.UserAddress;
import com.optum.test.userdata.entities.UserData;
import com.optum.test.userdata.repos.UserDataRepo;

@SpringBootTest
@AutoConfigureMockMvc
class UserDataControllerTest {
	
	
	private MockMvc mockMvc;
	
	@Mock
	private UserDataRepo userDataRepo;
	
	@InjectMocks
	private UserDataController dataController;
	
	private List<UserData> list ;
	
	private UserData userData;
	
	private ObjectMapper mapper = new ObjectMapper();

	@BeforeEach
	void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
		
		mockMvc = MockMvcBuilders.standaloneSetup(dataController).build();
		
		userData = new UserData();
		userData.setFirstName("Vijay");
		userData.setId(23);
		userData.setMiddleInitial("Kumar");
		userData.setLastName("Jidugu");
		userData.setPhoneNumber("7896541230");
		
		UserAddress userAddress = new UserAddress();
		userAddress.setCity("Atlanta");
		userAddress.setState("GA");
		userAddress.setZip("32123");
		userAddress.setId(23);
		userData.setAddress(userAddress);
		
		list = new ArrayList<UserData>();
		list.add(userData);
		
		
	}

	@Test
	void testGetAll() throws Exception {
		when(userDataRepo.findAll()).thenReturn(list);
		MvcResult result = this.mockMvc.perform(get("/UserData"))
					.andDo(print())
					.andExpect(status().isOk())
					.andReturn();
		assertTrue(result.getResponse().getContentAsString().contains("Vijay"));
	}

	@Test
	void testGetById() throws Exception {
		when(userDataRepo.findById((long) 23)).thenReturn(Optional.ofNullable(userData));
		MvcResult result = this.mockMvc.perform(get("/UserData/23"))
					.andDo(print())
					.andExpect(status().isOk())
					.andReturn();
		assertTrue(result.getResponse().getContentAsString().contains("Vijay"));
	}

	@Test
	void testCreateNewUserData() throws Exception {
		when(userDataRepo.save(any(UserData.class))).thenReturn((userData));
		MvcResult result = this.mockMvc.perform(post("/UserData")
				.accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON)
					.content(mapper.writeValueAsString(userData)))
					.andDo(print())
					.andExpect(status().isCreated())
					.andReturn();
		assertTrue(result.getResponse().getStatus()==201);
	}

	@Test
	void testUpdateUserData() throws JsonProcessingException, Exception {
		when(userDataRepo.save(any(UserData.class))).thenReturn((userData));
		MvcResult result = this.mockMvc.perform(put("/UserData")
				.accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON)
					.content(mapper.writeValueAsString(userData)))
					.andDo(print())
					.andExpect(status().isNoContent())
					.andReturn();
		assertTrue(result.getResponse().getStatus()==204);
	}

	@Test
	void testDeleteUserData() throws Exception {
		doNothing().when(userDataRepo).deleteById((long) 23);
		MvcResult result = this.mockMvc.perform(delete("/UserData")
				.contentType(MediaType.APPLICATION_JSON)
				.param("id", "23"))
				.andDo(print())
				.andExpect(status().isOk())
				.andReturn();
		assertTrue(result.getResponse().getStatus()==200);
	}

}
